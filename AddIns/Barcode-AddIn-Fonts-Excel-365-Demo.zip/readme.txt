Softmatic Barcode AddIn (365)

This is the DEMO version of the Softmatic Barcode AddIn for Excel 365. The demo
is fully functional but will only create Code 39 barcodes.

System requirements: Windows 10 or higher, Office / Excel 365

Installation 

Please close Excel before installing the fonts and add-in.

1. Installing the barcode font

- Open the folder "Fonts".
- In the folder select the font "Code 39".
- Right-click for context menu and select "Install".

2. Installing the add-in

- Double-click the file setup.exe and follow the instructions on the screen.

3. Verifying the installation and first steps

- Launch Excel
- In the ribbon, switch to the tab "Add-Ins".
- You should see a pane "Softmatic Barcode" with two buttons, "Create Barcode" and "Info".
- Click the "Info" button and verify that the barcode font "Code 39" is listed. Click "Close".
- In cell "A1", enter the value 1000. Hit <Enter>, then click into the cell to select it.
- Click the "Create Barcode" button. Leave all settings at default and click "Ok".
- You should see a barcode in cell "B1".
- Congratulations!

Please see https://softmatic.com/excel/manual.html for an extensive manual.

For questions and help, contact us at webb@softmatic.com. Put "Softmatic Barcode AddIn (365)" in the subject line.

For pricing and licensing options, point your browser to https://softmatic.com/store.html.

(c)1991-2024 Softmatic GmbH, Berlin, Germany. All rights reserved.